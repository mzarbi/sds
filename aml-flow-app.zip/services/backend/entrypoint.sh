#!/bin/sh
python manage.py run -h 0.0.0.0
