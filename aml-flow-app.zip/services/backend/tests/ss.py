import requests

r = requests.get('http://localhost:5001/tasks')
print(r.json())
