# backend/server/main/views.py
import json
from datetime import datetime

import requests
from celery.result import AsyncResult
from flask import Blueprint, jsonify, request

from ..celery_tasks import create_task, revoke_task_by_id, aml_task

tasks_blueprint = Blueprint("tasks", __name__, )


@tasks_blueprint.route("/tasks", methods=["POST"])
def run_task():
    content = request.json
    task_type = content["type"]
    task = aml_task.delay(
        int(task_type),
        maintainer="medzied.arbi@gmail.com",
        business_unit="Great Britain"
    )
    return jsonify({"task_id": task.id}), 202


@tasks_blueprint.route("/tasks/rm/<task_id>", methods=["GET"])
def revoke_task(task_id):
    revoke_task_by_id(task_id)
    return jsonify({"task_id": task_id}), 200


@tasks_blueprint.route("/tasks", methods=["GET"])
def all_tasks():
    r = requests.get('http://dashboard:5555/api/tasks', verify=False).json()
    ls = []
    for i in r:
        dc = r[i]
        dc.update({
            "maintainer": json.loads(r[i]["kwargs"].replace("'", '"'))["maintainer"],
            "business_unit": json.loads(r[i]["kwargs"].replace("'", '"'))["business_unit"]
        })
        task_result = AsyncResult(r[i]["uuid"])
        dc.update({
            "task_status": task_result.status,
            "task_result": task_result.result
        })
        ls.append(dc)
    return jsonify(ls), 200


@tasks_blueprint.route("/tasks-count", methods=["GET"])
def tasks_count():
    r = requests.get('http://dashboard:5555/api/tasks', verify=False)
    return jsonify(len(r.json().keys())), 200


@tasks_blueprint.route("/week-successful-tasks-count", methods=["GET"])
def week_tasks_count():
    r = requests.get('http://dashboard:5555/api/tasks', verify=False).json()
    counter = 0
    for i in r:
        if r[i]["succeeded"] is not None:
            now = datetime.now()
            if (datetime.fromtimestamp(r[i]["succeeded"]) - now).days < 7:
                counter += 1
    return jsonify(counter), 200


@tasks_blueprint.route("/anomalies-detected", methods=["GET"])
def anomalies_detected():
    return jsonify(0), 200


@tasks_blueprint.route("/tasks/<task_id>", methods=["GET"])
def get_status(task_id):
    task_result = AsyncResult(task_id)
    result = {
        "task_id": task_id,
        "task_status": task_result.status,
        "task_result": task_result.result
    }
    return jsonify(result), 200


@tasks_blueprint.route("/task/<task_id>", methods=["GET"])
def task(task_id):
    r = requests.get('http://dashboard:5555/api/tasks', verify=False).json()
    for i in r:
        dc = {}
        if task_id == r[i]["uuid"]:
            dc = r[i]
            dc.update({
                "maintainer": json.loads(r[i]["kwargs"].replace("'", '"'))["maintainer"],
                "business_unit": json.loads(r[i]["kwargs"].replace("'", '"'))["business_unit"]
            })
            task_result = AsyncResult(r[i]["uuid"])
            dc.update({
                "task_status": task_result.status,
                "task_result": task_result.result
            })
            return dc
    return jsonify(dc), 200
