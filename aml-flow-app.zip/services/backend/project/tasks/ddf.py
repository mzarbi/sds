from datetime import datetime



now = datetime.now()  # Add .date() if hour doesn't matter
print((datetime.fromtimestamp(1652050329.5996122) - now).days < 7)