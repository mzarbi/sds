# backend/server/main/views.py

from flask import Blueprint

gui_blueprint = Blueprint("gui", __name__,)