import json
import os
import time
from datetime import datetime

from celery import Celery, current_task
from celery.worker.control import revoke

celery = Celery(__name__)
celery.conf.broker_url = os.environ.get("CELERY_BROKER_URL", "redis://localhost:6379")
celery.conf.result_backend = os.environ.get("CELERY_RESULT_BACKEND", "redis://localhost:6379")


@celery.task(name="create_task")
def create_task(task_type,maintainer="medzied.arbi@gmail.com"):
    for i in range(int(task_type) * 10):
        current_task.update_state(state='PROGRESS 2',
                                  meta={'current': i, 'total': int(task_type) * 10})
        time.sleep(1)
    return True


@celery.task(name="AML_TASK")
def aml_task(
        task_type,
        maintainer="medzied.arbi@gmail.com",
        business_unit="Great Britain"):
    ls = []
    for i in range(int(task_type) * 10):
        now = datetime.now()  # current date and time
        dt = now.strftime('%X %x')

        ls.append({
            "label" : f"Step {i}",
            "time" : dt
        })
        current_task.update_state(
            state='PROGRESS',
            meta={
                'current': i,
                'total': int(task_type) * 10,
                'percentage' : float(str(i/(int(task_type) * 10)*100)[:4]),
                'steps' : ls
            }
        )
        time.sleep(1)
    return {
        'current': int(task_type) * 10,
        'total': int(task_type) * 10,
        'percentage' : 100,
        'steps' : ls
    }


def generate_custom_state(label='PROGRESS',step=0,total=0,msg=''):
    return json.dumps({
        "label" : label,
        "step" : step,
        "total" : total,
        "msg" : msg
    })
def revoke_task_by_id(task_id):
    revoke(task_id, terminate=True)
