import os

from flask import Flask
from flask_cors import CORS


def create_app(script_info=None):
    # instantiate the app
    app = Flask(
        __name__,
        template_folder="../client/templates",
        static_folder="../client/static",
    )
    CORS(app)
    # set config
    app_settings = os.getenv("APP_SETTINGS")
    app.config.from_object(app_settings)

    # register blueprints
    from .main.routes import main_blueprint
    from .tasks.routes import tasks_blueprint
    from .gui.routes import gui_blueprint

    app.register_blueprint(main_blueprint)
    app.register_blueprint(tasks_blueprint)
    app.register_blueprint(gui_blueprint)

    # shell context for flask cli
    app.shell_context_processor({"app": app})

    return app
