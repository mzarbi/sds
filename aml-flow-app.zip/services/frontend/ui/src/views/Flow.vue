


<template>
  <div class="py-4 container-fluid">
    <div class="row">
      <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
        <mini-statistics-card
          title="Today's Flows"
          value="10 flows"
          :percentage="{
            value: '+505%',
            color: 'text-success',
          }"
          :icon="{
            component: 'ni ni-money-coins',
            background: iconBackground,
          }"
          direction-reverse
        />
      </div>
      <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
        <mini-statistics-card
          title="Anomalies Detected"
          value="+3,462"
          :percentage="{
            value: '-2%',
            color: 'text-danger',
          }"
          :icon="{
            component: 'ni ni-paper-diploma',
            background: iconBackground,
          }"
          direction-reverse
        />
      </div>
    </div>
    <div class="row">
      <div class="col-lg-4 col-md-6">
        <timeline-list
          class="h-100"
          :title = uuid
          :description = description()
        >
          <timeline-item v-for="step in task.task_result.steps" :key="step.id"
            color="success"
            icon="bell-55"
            :title=step.label
            :date-time=step.time>
          </timeline-item>
        </timeline-list>
      </div>


    </div>
    <div class="row my-4">
      <div>
        <projects-card />
      </div>
    </div>
  </div>
</template>
<script>
import axios from 'axios';
import TimelineList from "./components/TimelineList.vue";
import TimelineItem from "./components/TimelineItem.vue";
export default {
  name: "tables",
  data() {
    return {
      uuid : this.$route.params.uuid,
      task: {}
    };
  },
  methods: {
    description(){
        if(this.task.state == "SUCCESS"){
            return "<i class='fa fa-arrow-up text-success' aria-hidden='true'></i><span class='font-weight-bold'> " + this.task.state + "</span>";
        }else{
            return "<span class='font-weight-bold'> " + this.task.state + "</span>";
        }
    },
    compute_percentage(task){
        if(task.task_status == "SUCCESS"){
            return 100;
        }
        if(task.task_status == "PROGRESS"){
            return task.task_result.percentage;
        }
        return 0;
    },
    getTask() {
      const path = 'http://localhost:5001/task/' + this.uuid;
      axios.get(path)
        .then((res) => {
          this.task = res.data;
        })
        .catch((error) => {
          console.error(error);
        });
    },
  },
  created() {
    this.getTask();
  },
  components: {
    TimelineList,TimelineItem
  },
};
</script>
