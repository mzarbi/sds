import setuptools

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="flow_manager",
    version="0.0.1",
    author="Mohamed Zied El Arbi",
    author_email="medzied.arbi@gmail.com",
    description="This is a simple flow manager",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="",
    project_urls={
        "Bug Tracker": "",
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    package_dir={"": "src/flow_manager"},
    packages=setuptools.find_packages(where="src/flow_manager") + ["flow/resources"],
    package_data={'flow/resources':['*']},
    python_requires=">=3.6",
)