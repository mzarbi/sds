# This code parses date/times, so please
#
#     pip install python-dateutil
#
# To use this code, make sure you
#
#     import json
#
# and then, to convert JSON from a string, do
#
#     result = flow_manifest_from_dict(json.loads(json_string))

from dataclasses import dataclass
from typing import Any, List, TypeVar, Callable, Type, cast
from datetime import datetime
import dateutil.parser


T = TypeVar("T")


def from_str(x: Any) -> str:
    assert isinstance(x, str)
    return x


def from_datetime(x: Any) -> datetime:
    return dateutil.parser.parse(x)


def from_list(f: Callable[[Any], T], x: Any) -> List[T]:
    assert isinstance(x, list)
    return [f(y) for y in x]


def to_class(c: Type[T], x: Any) -> dict:
    assert isinstance(x, c)
    return cast(Any, x).to_dict()


@dataclass
class Manifest:
    unit: str
    status: str

    @staticmethod
    def from_dict(obj: Any) -> 'Manifest':
        assert isinstance(obj, dict)
        unit = from_str(obj.get("unit"))
        status = from_str(obj.get("status"))
        return Manifest(unit, status)

    def to_dict(self) -> dict:
        result: dict = {}
        result["unit"] = from_str(self.unit)
        result["status"] = from_str(self.status)
        return result


@dataclass
class FlowManifest:
    flow: str
    date_started: datetime
    manifest: List[Manifest]

    @staticmethod
    def from_dict(obj: Any) -> 'FlowManifest':
        assert isinstance(obj, dict)
        flow = from_str(obj.get("flow"))
        date_started = from_datetime(obj.get("date_started"))
        manifest = from_list(Manifest.from_dict, obj.get("manifest"))
        return FlowManifest(flow, date_started, manifest)

    def to_dict(self) -> dict:
        result: dict = {}
        result["flow"] = from_str(self.flow)
        result["date_started"] = self.date_started.isoformat()
        result["manifest"] = from_list(lambda x: to_class(Manifest, x), self.manifest)
        return result


def flow_manifest_from_dict(s: Any) -> FlowManifest:
    return FlowManifest.from_dict(s)


def flow_manifest_to_dict(x: FlowManifest) -> Any:
    return to_class(FlowManifest, x)
