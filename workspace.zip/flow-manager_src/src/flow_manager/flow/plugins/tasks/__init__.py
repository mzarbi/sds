from flow.models.flow_model import Task
import imp
import os

from flow.struct.abstract_task import AbstractTask, AbstractNestedTask
from flow.utils.decorators import error


def load_task_addons():
    task_addons_path = os.environ["ADDONS_PATH"] + "/addons/__init__.py"
    imp.load_source('tasks', task_addons_path)


def all_subclasses(cls):
    return set(cls.__subclasses__()).union(
        [s for c in cls.__subclasses__() for s in all_subclasses(c)])


def task_lookup(task: Task):
    load_task_addons()
    for tmp in all_subclasses(AbstractTask):
        if tmp.__name__ == task.class_name:
            return tmp
    error(f"Could not find a task implementation with the following name {task.class_name}")
    return None


def subtask_lookup(task: Task):
    load_task_addons()
    for tmp in all_subclasses(AbstractNestedTask):
        if tmp.__name__ == task.class_name:
            return tmp
    error(f"Could not find a task implementation with the following name ({task.class_name})")
    return None
