import multiprocessing
import os
import uuid
from datetime import datetime
from os import environ
from dotenv import load_dotenv
from flow.utils.converters import convert, camel_case_to_whites
from flow.utils.decorators import decorate, error
from flow.resources.loaders import load_yaml_from_local_resources, load_json_from_resources, load_yaml_from_resources
from flow.plugins.tasks import task_lookup
from flow.manifest import ManifestDB, Query


class AbstractFlow:
    def __init__(self):
        self.uuid = str(uuid.uuid4())
        self.flow_cfg = FlowCfg()
        self.current_task_wrapper = None
        self.data = {}
        self.lock = None
        self.manifest = None
        self.breakpoints = []

    def put(self, key, val):
        self.data[key] = val

    def get(self, key):
        return self.data.get(key)

    def env(self):
        return self.flow_cfg.env

    def specs(self):
        return self.flow_cfg.specs

    @decorate(name="Initializing flow", show_delta=False)
    def initialize(self, flow_specs):
        self.load_env_variables()
        self.load_flow_specs(flow_specs)
        self.validate_entry_point_wrapper()
        self.initialize_slots()
        self.init_manifest()
        return self

    @decorate(name="Initializing manifest", indent=1, show_delta=False)
    def init_manifest(self):
        manifest_path = self.env().CACHE_PATH + "/" + "manifest.json"
        self.manifest = ManifestDB(manifest_path)
        self.manifest.insert({
            'uuid': self.uuid,
            'state': 'SUBMITTED',
            "breakpoints": self.breakpoints,
            'start': datetime.now().strftime("%m-%d-%Y %H:%M:%S")
        })

    @decorate(name="Loading flow specs", indent=1, show_delta=False)
    def load_flow_specs(self, flow_specs):
        self.flow_cfg.specs = flow_specs

    @decorate(name="Loading environment variables", indent=1, show_delta=False)
    def load_env_variables(self):
        load_dotenv()
        for tmp in load_yaml_from_resources("env_vars.yaml")["variables"]:
            setattr(self.flow_cfg.env, tmp["name"], convert(environ[tmp["name"]], tmp["datatype"]))

    @decorate(name="Validating entry point wrapper", indent=1, show_delta=False)
    def validate_entry_point_wrapper(self):
        self.current_task_wrapper = self.find_entry_point()

        if self.current_task_wrapper is None:
            error(f"Could not find a task wrapper for the provided entry point '{self.specs().entry_point}'")
            exit(-1)

    @decorate(name="Initializing slots", indent=1, show_delta=False)
    def initialize_slots(self):
        for tmp in self.specs().tasks:
            self.data[f'{tmp.marker}_on_success'] = True
            for slot in tmp.slots.custom_slots:
                self.data[f'{tmp.marker}_{slot.name}'] = False
            for tmp2 in tmp.sub_tasks:
                self.data[f'{tmp.marker}_{tmp2.marker}_on_success'] = True
                for tmp3 in tmp2.slots.custom_slots:
                    self.data[f'{tmp.marker}_{tmp2.marker}_{tmp3.name}'] = False

    def find_entry_point(self):
        for tmp in self.specs().tasks:
            if tmp.marker == self.specs().entry_point:
                return tmp

    def update_state(self,state):
        with self.lock:
            self.manifest.update({
                'state': state,
                'end': datetime.now().strftime("%d-%b-%Y (%H:%M:%S.%f)")
            }, Query().uuid == self.uuid)

    @decorate(name="Running Tasks", indent=0)
    def run(self,lock):
        self.lock = lock
        while True:
            @decorate(name=f"Starting to run ({camel_case_to_whites(self.current_task_wrapper.class_name)})", indent=1)
            def resolve_task(current_wrapper):
                task = task_lookup(current_wrapper)(current_wrapper, self,lock)
                task.pre_run()
                task.run()
                task.post_run()

                return self.next_task(current_wrapper, self.specs().tasks)

            self.current_task_wrapper = resolve_task(self.current_task_wrapper)
            if self.current_task_wrapper is None:
                break
        self.update_state("SUCCESS")

    def next_task(self, task, tasks):
        if type(task.slots) == str:
            return self.task_by_marker(task.slots, tasks)
        else:
            for slot in task.slots.custom_slots:
                field = self.data[f'{task.marker}_{slot.name}']
                if field:
                    return self.task_by_marker(slot.on_true, tasks)
                else:
                    return self.task_by_marker(slot.on_false, tasks)

            field = self.data[f'{task.marker}_on_success']
            if field:
                return self.task_by_marker(task.slots.on_success, tasks)
            else:
                return self.task_by_marker(task.slots.on_failure, tasks)

    def task_by_marker(self, marker, tasks):
        for tmp in tasks:
            if tmp.marker == marker:
                return tmp


class FlowRunner:
    def __init__(self):
        self.flow = AbstractFlow()

    def wrapper(self, run):
        while True:
            if run.value == 1:
                self.flow.initialize().run()

    def run(self):
        os.environ[f"FLOW_STATUS_{self.flow.id}"] == "1"
        run = multiprocessing.Value("flow_status", int(os.environ["FLOW_STATUS_" + self.flow.id]))
        p = multiprocessing.Process(target=self.wrapper, args=(run,))
        p.start()


class FlowCfg:
    def __init__(self):
        self.env = type('', (), {})()
        self.specs = type('', (), {})()


if __name__ == "__main__":
    AbstractFlow().initialize().run()
