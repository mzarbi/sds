import logging
import os
from functools import wraps
from re import search
import pickle
import time

from flow.utils.converters import convert

LOGGER = logging.getLogger(__name__)
INDENTATION_STEP = 2


def singleton(cls):
    """Make a class a Singleton class (only one instance)"""

    @wraps(cls)
    def wrapper_singleton(*args, **kwargs):
        if not wrapper_singleton.instance:
            wrapper_singleton.instance = cls(*args, **kwargs)
        return wrapper_singleton.instance

    wrapper_singleton.instance = None
    return wrapper_singleton


def is_match(_lambda, pattern):
    def wrapper(f):
        @wraps(f)
        def wrapped(self, *f_args, **f_kwargs):
            if callable(_lambda) and search(pattern, (_lambda(self) or '')):
                f(self, *f_args, **f_kwargs)

        return wrapped

    return wrapper


def skippable():
    def wrapper(f):
        @wraps(f)
        def wrapped(self, *f_args, **f_kwargs):
            if not self.mark_as_ignored:
                f(self, *f_args, **f_kwargs)

        return wrapped

    return wrapper


def decorate(name, indent=0, show_delta=True):
    def wrapper(f):
        @wraps(f)
        def wrapped(self, *f_args, **f_kwargs):
            start_time = time.time()
            info(name, indent)
            res = f(self, *f_args, **f_kwargs)
            if show_delta:
                info(name + " finished with success %s s" % (time.time() - start_time), indent)
            return res

        return wrapped

    return wrapper


def cache(pattern, name, indent=0, format="pickle"):
    def wrapper(f):
        @wraps(f)
        def wrapped(self, *f_args, **f_kwargs):
            start_time = time.time()
            info(name, indent)
            cch = load_cache(self.breakpoint_path + "/" + pattern, format)
            if cch is not None:
                info(name + " cache loaded with success %s s" % (time.time() - start_time), indent)
                return cch
            else:
                res = f(self, *f_args, **f_kwargs)
                save_cache(res, self.breakpoint_path + "/" + pattern, format)
                info(name + " finished with success %s s" % (time.time() - start_time), indent)
                return res

        return wrapped

    return wrapper


def save_cache(res, pth, format):
    if format == "pickle":
        return save_pickle(res, pth)


def save_pickle(res, pth):
    with open(pth, "wb") as f:
        pickle.dump(res, f)


def load_cache(pth, format):
    if not os.path.isfile(pth):
        return None
    if format == "pickle":
        return load_pickle(pth)


def load_pickle(pth):
    with open(pth, "rb") as f:
        return pickle.load(f)


def log(v, indent=0):
    if convert(os.environ["LOGGING"], "bool"):
        print(indent * INDENTATION_STEP * " ", v)


def info(v, indent=0):
    if convert(os.environ["LOGGING"], "bool"):
        print(indent * INDENTATION_STEP * " " + "[INFO]", v)


def error(v, indent=0):
    if convert(os.environ["LOGGING"], "bool"):
        print(indent * INDENTATION_STEP * " " + "[ERROR]", v)
