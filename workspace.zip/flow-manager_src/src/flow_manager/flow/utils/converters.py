import json
import re


def convert(value, datatype):
    if datatype == "str":
        return str(value)
    if datatype == "int":
        return int(value)
    if datatype == "bool":
        return json.loads(value.lower())
    return value


def camel_case_to_underscore(identifier, remove_single_letter_words=False):
    return "_".join(camel_case_split(identifier, remove_single_letter_words=remove_single_letter_words)).lower()


def camel_case_to_whites(identifier, remove_single_letter_words=False):
    s = [capitalize(f) for f in camel_case_split(identifier, remove_single_letter_words=remove_single_letter_words)]
    return " ".join(s)


def class_name_condition(identifier, remove_single_letter_words=False):
    s = [f for f in camel_case_split(identifier, remove_single_letter_words=remove_single_letter_words)]
    return "_".join(s) + "_condition"


def capitalize(s):
    return s[0].upper() + s[1:]


def camel_case_split(identifier, remove_single_letter_words=False):
    """Parses CamelCase and Snake naming"""
    concat_words = re.split('[^a-zA-Z]+', identifier)

    def camel_case_split(string):
        bldrs = [[string[0].upper()]]
        string = string[1:]
        for idx, c in enumerate(string):
            if bldrs[-1][-1].islower() and c.isupper():
                bldrs.append([c])
            elif c.isupper() and (idx + 1) < len(string) and string[idx + 1].islower():
                bldrs.append([c])
            else:
                bldrs[-1].append(c)

        words = [''.join(bldr) for bldr in bldrs]
        words = [word.lower() for word in words]
        return words

    words = []
    for word in concat_words:
        if len(word) > 0:
            words.extend(camel_case_split(word))
    if remove_single_letter_words:
        subset_words = []
        for word in words:
            if len(word) > 1:
                subset_words.append(word)
        if len(subset_words) > 0:
            words = subset_words
    return words
