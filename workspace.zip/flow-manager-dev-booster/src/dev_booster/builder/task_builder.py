import json
import os

from flow.models.flow_model import flow_model_from_dict
from flow.models.task_addon_model import task_addon_model_from_dict, TaskAddonModel
from flow.utils.converters import camel_case_to_underscore, camel_case_to_whites


class TaskBuilder:
    def __init__(self, output_path=""):
        self.tasks = []
        self.output_path = output_path

    def add_flow_file(self, pth):
        with open(pth, "r") as f:
            md = flow_model_from_dict(json.load(f))
        for tmp in md.tasks:
            tsk = TaskAddonModel(tmp.class_name, tmp.description, [f.name for f in tmp.slots.custom_slots])
            tsk.sub_tasks = []
            for tmp2 in tmp.sub_tasks:
                tsk2 = TaskAddonModel(tmp2.class_name, tmp2.description, [f.name for f in tmp2.slots.custom_slots])
                tsk.sub_tasks.append(tsk2)
            self.tasks.append(tsk)

        return self

    def build_package(self, p):
        self.build_dir(p)
        with open(p + "/__init__.py", "w") as f:
            f.write("")

    def build_dir(self, p):
        try:
            os.mkdir(p)
        except:
            pass

    def add_model_file(self, pth):
        with open(pth, "r") as f:
            self.tasks.append(task_addon_model_from_dict(json.load(f)))
        return self

    def build_manage(self, pth):
        with open(pth + "/manage.py", "w") as f:
            f.write('''from dotenv import load_dotenv
from flask.cli import FlaskGroup

from server import create_app

load_dotenv()
app = create_app()
cli = FlaskGroup(create_app=create_app)


@cli.command('help')
def help():
    print('help')


if __name__ == "__main__":
    cli()

''')

    def build_server_config(self, pth):
        with open(pth + "/config.py", "w") as f:
            f.write('''class BaseConfig:
    TESTING = False


class DevelopmentConfig(BaseConfig):
    TESTING = False
    WTF_CSRF_ENABLED = False


class TestingConfig(BaseConfig):
    TESTING = True
    WTF_CSRF_ENABLED = False
    PRESERVE_CONTEXT_ON_EXCEPTION = False


class ProductionConfig(BaseConfig):
    TESTING = False
    WTF_CSRF_ENABLED = False''')

    def build_server_init(self, pth):
        with open(pth + "/__init__.py", "w") as f:
            f.write('''import os

from flask import Flask
from flask_cors import CORS


def create_app(script_info=None):
    # instantiate the app
    app = Flask(
        __name__,
        template_folder="../client/templates",
        static_folder="../client/static",
    )
    CORS(app)
    # set config
    app_settings = os.getenv("APP_SETTINGS")
    app.config.from_object(app_settings)

    # register blueprints
    from .api.routes import api_blueprint
    from .client.routes import client_blueprint

    app.register_blueprint(api_blueprint)
    app.register_blueprint(client_blueprint)

    # shell context for flask cli
    app.shell_context_processor({"app": app})

    return app''')

    def build__init__(self, pth, model):
        with open(pth + "/__init__.py", "w") as f:
            f.write("")

    def build_client_routes(self, pth):
        with open(pth + "/routes.py", "w") as f:
            f.write("""from flask import render_template, Blueprint

client_blueprint = Blueprint("main", __name__,)


@client_blueprint.route("/", methods=["GET"])
def home():
    return render_template("main/home.html")""")

    def build_main_routes(self, pth,p2):
        with open(pth + "/routes.py", "w") as f:
            f.write("""from threading import Lock
import os
from flask import Blueprint, request, jsonify
from flow.manifest import ManifestDB, Query
from flow.models.flow_model import flow_model_from_dict
from flow.resources.loaders import load_json
from flow.struct.abstract_executor import CustomThreadPoolExecutor

api_blueprint = Blueprint("api", __name__, url_prefix='/api')
executor = CustomThreadPoolExecutor(max_workers=3, lock=Lock())


def load_manifest():
    manifest_path = os.environ["CACHE_PATH"] + "/" + "manifest.json"
    return ManifestDB(manifest_path)


@api_blueprint.route("/tasks", methods=["POST"])
def run_flow():
    content = request.json
    # flow_specs = flow_model_from_dict(content["flow_specs"])
    flow_specs = flow_model_from_dict(load_json(r"##\\flow.json"))
    uuid = executor.register_flow(flow_specs)
    return jsonify({"task_id": uuid}), 202


@api_blueprint.route("/tasks", methods=["GET"])
def fetch_tasks():
    return jsonify([{
        "uuid": f["uuid"],
        "start": f.get("start", ""),
        "end": f.get("end", ""),
        "state": f.get("state", "")
    } for f in load_manifest().all()]), 202


@api_blueprint.route("/task/raw/<task_id>", methods=["GET"])
def task(task_id):
    ls = load_manifest().search(Query().uuid == task_id)
    return jsonify(ls[0] if len(ls) > 0 else {}), 200


@api_blueprint.route("/task/sig/<task_id>", methods=["GET"])
def task_signature(task_id):
    def compute_progress(task):
        if task.get("state", "") == "SUCCESS":
            return 100
        else:
            return 0

    ls = [{
        "uuid": f["uuid"],
        "start": f.get("start", ""),
        "end": f.get("end", ""),
        "state": f.get("state", ""),
        "progress": compute_progress(f)
    } for f in load_manifest().search(Query().uuid == task_id)]
    return jsonify(ls[0] if len(ls) > 0 else {}), 200


@api_blueprint.route("/task/breakpoints/<task_id>", methods=["GET"])
def task_breakpoints(task_id):
    ls = [[g for g in f.get("breakpoints", [])] for f in load_manifest().search(Query().uuid == task_id)]

    ls = ls[0] if len(ls) > 0 else []
    ls2 = [i for i in ls if i.get("parent", None) is None]
    for i in ls2:
        i.update({
            "sub-breakpoints": [j for j in ls if j.get("parent", None) == i["uuid"]]
        })
    return jsonify(ls2), 200
""".replace("##",p2))

    def build__commons(self, p, model):
        with open(p + "/commons.py", "w") as f:
            f.write("")

    def build_dot_env(self, pth):
        with open(pth + "/.env", "w") as f:
            f.write(f"""
DEBUG=True
LOGGING=True
RESOURCES_PATH={pth}\\resources
ADDONS_PATH={pth}\\
CACHE_PATH={pth}\\cache
""")

    def build_footer_html(self, pth):
        with open(pth + "/footer.html", "w") as f:
            f.write("""<footer class="footer">
  <div class="container">
    <small><span class="text-muted">C <a href="https://testdriven.io">TestDriven.io</a></span></small>
  </div>
</footer>

""")

    def build_home_html(self, pth):
        with open(pth + "/home.html", "w") as f:
            f.write("""{% extends "_base.html" %}

{% block content %}

<div class="starter-template">
  <h1>Flask + Celery + Docker</h1>
  <hr><br>
  <div>
    <h3>Tasks</h3>
    <p>Pick a task length.</p>
    <div class="btn-group" role="group" aria-label="Basic example">
      <button type="button" class="btn btn-primary" onclick="handleClick(1)">Short</button>
      <button type="button" class="btn btn-primary" onclick="handleClick(2)">Medium</button>
      <button type="button" class="btn btn-primary" onclick="handleClick(3)">Long</button>
    </div>
  </div>
  <br><br>
  <div>
    <h3>Task Status</h3>
    <br>
    <table class="table">
      <thead>
        <tr>
          <th>ID</th>
          <th>Status</th>
          <th>Result</th>
        </tr>
      </thead>
      <tbody id="tasks">
      </tbody>
    </table>
  </div>
</div>

{% endblock %}


""")
    def build_base_html(self, pth):
        with open(pth + "/_base.html", "w") as f:
            f.write("""<!DOCTYPE html>
<html>

  <head>
    <meta charset="utf-8">
    <title>Flask + Celery + Docker{% block title %}{% endblock %}</title>
    <!-- meta -->
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <!-- styles -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
    <link href="{{url_for('static', filename='main.css')}}" rel="stylesheet" media="screen">
    {% block css %}{% endblock %}
  </head>

  <body>

    <div class="container">
      <!-- child template -->
      {% block content %}{% endblock %}
    </div>

    {% include 'footer.html' %}

    <!-- scripts -->
    <script src="{{url_for('static', filename='main.js')}}" type="text/javascript"></script>
    {% block js %}{% endblock %}

  </body>

</html>


""")
    def build_main_css(self, pth):
        with open(pth + "/main.css", "w") as f:
            f.write("""/* custom css */

html {
  position: relative;
  min-height: 100%;
}
body {
  padding-top: 2rem;
  margin-bottom: 60px;
}
.footer {
  position: absolute;
  bottom: 0;
  width: 100%;
  height: 50px;
  line-height: 50px;
}
""")

    def build_main_js(self, pth):
        with open(pth + "/main.js", "w") as f:
            f.write("""// custom javascript

(function() {
  console.log('Sanity Check!');
})();

function handleClick(type) {
  fetch('/api/tasks', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ type: type }),
  })
  .then(response => response.json())
  .then(data => getStatus(data.task_id));
}

function getStatus(taskID) {
  fetch(`/api/task/sig/${taskID}`, {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json'
    },
  })
  .then(response => response.json())
  .then(res => {
    const html = `
      <tr>
        <td>${taskID}</td>
        <td>${res.state}</td>
        <td>${res.progress}</td>
      </tr>`;
    const newRow = document.getElementById('tasks').insertRow(0);
    newRow.innerHTML = html;

    const taskStatus = res.state;
    if (taskStatus === 'SUCCESS' || taskStatus === 'FAILURE') return false;
    setTimeout(function() {
      getStatus(res.uuid);
    }, 1000);
  })
  .catch(err => console.log(err));
}

""")

    def build_env_vars(self, pth):
        with open(pth + "/env_vars.yaml", "w") as f:
            f.write("""---
variables:
- name: 'DEBUG'
  datatype: 'bool'
- name: 'LOGGING'
  datatype: 'bool'
- name: 'RESOURCES_PATH'
  datatype: 'str'
- name: 'CACHE_PATH'
  datatype: 'str'
""")

    def build__task(self, pth, model):
        with open(pth + "/task.py", "w") as f:
            f.write(f'''from flow.struct.abstract_task import AbstractTask
from flow.utils.decorators import skippable


class {model.class_name}(AbstractTask):
    """{model.description}"""

    def __init__(self,task_cfg, flow,lock):
        """
        {camel_case_to_whites(model.class_name)} Task constructor
        :param task_cfg: Task object (flow.models.flow_model.Task)
        :param flow: AbstractFlow object (flow.struct.abstract_flow.AbstractFlow)
        """
        super().__init__(task_cfg,flow,lock)
    
    def name(self):
        return '{camel_case_to_whites(model.class_name)}'

    @skippable()
    def run(self):
        super().run()

    def update_task_state(self, value):
        self.flow.data[{"f'{self.task_cfg.marker}_on_success'"}] = value
''')
            for tmp in model.custom_slots:
                f.write(f'''
    def update_{tmp}_slot(self,value):
        self.flow.data[{"f'{self.task_cfg.marker}_" + tmp + "'"}] = value

''')

    def build__subtask(self, pth, model):
        with open(pth + "/sub_tasks.py", "w") as f:
            f.write("from flow.struct.abstract_task import AbstractNestedTask\n")
            f.write("from flow.utils.decorators import skippable")
            for tmp in model.sub_tasks:
                f.write(f'''


class {tmp.class_name}(AbstractNestedTask):
    """{tmp.description}"""

    def __init__(self,task_cfg, flow,parent_task,lock):
        super().__init__(task_cfg, flow,parent_task,lock)
    
    def name(self):
        return '{camel_case_to_whites(tmp.class_name)}'
        
    @skippable()
    def run(self):
        super().run()

    def update_task_state(self, value):
        self.flow.data[{"f'{self.task_cfg.marker}_on_success'"}] = value
''')
                for tmp2 in tmp.custom_slots:
                    f.write(f'''
    def update_{tmp2}_slot(self,value):
        self.flow.data[{"f'{self.task_cfg.marker}_" + tmp2 + "'"}] = value
''')

    def build(self):
        self.backend_path = self.output_path + "/" + "services/backend"
        self.build_dir(self.output_path + "/" + "services")
        self.build_dir(self.backend_path)
        self.build_manage(self.backend_path)
        self.build_dir(self.backend_path + "/" + "server")
        self.build_server_init(self.backend_path + "/" + "server")
        self.build_server_config(self.backend_path + "/" + "server")
        self.build_package(self.backend_path + "/" + "server/client")
        self.build_client_routes(self.backend_path + "/" + "server/client")
        self.build_package(self.backend_path + "/" + "server/api")
        self.build_main_routes(self.backend_path + "/" + "server/api",self.output_path)
        self.build_dir(self.backend_path + "/" + "client")
        self.build_dir(self.backend_path + "/" + "client/static")
        self.build_main_css(self.backend_path + "/" + "client/static")
        self.build_main_js(self.backend_path + "/" + "client/static")

        self.build_dir(self.backend_path + "/" + "client/templates")
        self.build_footer_html(self.backend_path + "/" + "client/templates")
        self.build_base_html(self.backend_path + "/" + "client/templates")
        self.build_dir(self.backend_path + "/" + "client/templates/main")
        self.build_home_html(self.backend_path + "/" + "client/templates/main")

        self.build_main_js(self.backend_path + "/" + "client/static")
        self.build_dir(self.backend_path + "/" + "cache")
        self.build_dir(self.backend_path + "/" + "resources")
        self.build_env_vars(self.backend_path + "/" + "resources")
        self.build_dot_env(self.backend_path)
        self.build_dir(self.backend_path + "/" + "addons")
        with open(self.backend_path + "/addons/__init__.py", "w") as f:
            for model in self.tasks:
                package_name = camel_case_to_underscore(model.class_name)
                f.write(f"from .tasks.{package_name}.task import *\n")
                f.write(f"from .tasks.{package_name}.sub_tasks import *\n\n")

        self.build_dir(self.backend_path + "/" + "addons/tasks")
        with open(self.backend_path + "/addons/tasks/__init__.py", "w") as f:
            f.write("")
        for model in self.tasks:
            package_name = camel_case_to_underscore(model.class_name)
            self.build_dir(self.backend_path + "/addons/tasks/" + package_name)
            self.build__init__(self.backend_path + "/addons/tasks/" + package_name, model)
            self.build__task(self.backend_path + "/addons/tasks/" + package_name, model)
            self.build__subtask(self.backend_path + "/addons/tasks/" + package_name, model)
            self.build__commons(self.backend_path + "/addons/tasks/" + package_name, model)


def camel_case_to_whites(s):
    return ''.join(' ' + c if c.isupper() else c for c in s).strip()


if __name__ == "__main__":
    TaskBuilder(r'C:\Users\medzi\Desktop\workspace\sample'). \
        add_flow_file(
        r"C:\Users\medzi\Desktop\workspace\sample\flow.json").build()
