from threading import Lock

from builder.task_builder import TaskBuilder
from dotenv import load_dotenv
from flow.models.flow_model import flow_model_from_dict
from flow.resources.loaders import load_json
from flow.struct.abstract_executor import CustomThreadPoolExecutor

if __name__ == "__main__":
    load_dotenv()

    TaskBuilder(r'C:\Users\medzi\Desktop\workspace\sample\addons\tasks'). \
        add_flow_file(
        r"C:\Users\medzi\Desktop\workspace\sample\flow.json").build()
    #flow_specs = flow_model_from_dict(load_json(r"C:\Users\medzi\Desktop\workspace\sample\flow.json"))
    #lk = Lock()
    #CustomThreadPoolExecutor(max_workers=3,lock=lk).register_flow(flow_specs)
    #CustomThreadPoolExecutor(max_workers=3, lock=lk).register_flow(flow_specs)
    #AbstractFlow().initialize(flow_specs).run(lk)