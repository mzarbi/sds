<template>
  <div class="py-4 container-fluid">
    <div class="row">
      <div class="col-12">
        <projects-card />
      </div>
    </div>
  </div>
</template>

<script>
import ProjectsCard from "./components/ProjectsCardComplete.vue";
export default {
  name: "tables",
  components: {
    ProjectsCard
  },
};
</script>
