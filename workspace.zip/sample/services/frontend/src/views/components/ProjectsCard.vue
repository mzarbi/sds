<template>
  <div class="card">
    <div class="card-header pb-0">
      <div class="row">
        <div class="col-lg-6 col-7">
          <h6>Flows</h6>
          <p class="text-sm mb-0">
            <i class="fa fa-check text-info" aria-hidden="true"></i>
            <span class="font-weight-bold ms-1">{{ successful_week_tasks + " done"}}</span> this week
          </p>
        </div>
        <div class="col-lg-6 col-5 my-auto text-end">

        </div>
      </div>
    </div>
    <div class="card-body px-0 pb-2">
      <div class="table-responsive">
        <table class="table align-items-center mb-0">
          <thead>
            <tr>
              <th
                class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7"
              >
                Flows
              </th>
              <th
                class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2"
              >
                Responsable
              </th>
              <th
                class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7"
              >
                Business Units
              </th>
              <th
                class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7"
              >
                Completion
              </th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="task in tasks" :key="task.id">
                <td>
                    <div class="d-flex px-2 py-1">
                      <div class="d-flex flex-column justify-content-center">
                        <h6 class="mb-0 text-sm"><a :href=task_url(task)>{{task.uuid}}</a></h6>
                      </div>
                    </div>
                </td>
                <td>
                    <div class="d-flex px-2 py-1">
                      <div class="d-flex flex-column justify-content-center">
                        <h6 class="mb-0 text-sm">{{task.start}}</h6>
                      </div>
                    </div>
                </td>
                <td class="align-middle text-center text-sm">
                    <span class="text-xs font-weight-bold">{{task.name}}</span>
                </td>
                <td class="align-middle">
                    <div class="d-flex align-items-center justify-content-center">
                      <span class="text-xs font-weight-bold mx-2">{{ compute_percentage(task) + " %"}}</span>
                      <div>
                        <vsud-progress
                          color="info"
                          class="mx-auto"
                          variant="gradient"
                          :percentage=compute_percentage(task)
                        />
                      </div>
                    </div>
                  </td>
            </tr>

          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script>
import setTooltip from "@/assets/js/tooltip.js";
import VsudProgress from "@/components/VsudProgress.vue";
import img1 from "../../assets/img/small-logos/logo-xd.svg";
import img2 from "../../assets/img/team-1.jpg";
import img3 from "@/assets/img/team-2.jpg";
import img4 from "../../assets/img/team-3.jpg";
import img5 from "../../assets/img/team-4.jpg";
import img6 from "../../assets/img/small-logos/logo-atlassian.svg";
import img7 from "../../assets/img/team-2.jpg";
import img8 from "../../assets/img/team-4.jpg";
import img9 from "../../assets/img/small-logos/logo-slack.svg";
import img10 from "../../assets/img/team-3.jpg";
import img11 from "../../assets/img/team-1.jpg";
import img12 from "../../assets/img/small-logos/logo-spotify.svg";
import img13 from "../../assets/img/team-4.jpg";
import img14 from "../../assets/img/team-3.jpg";
import img15 from "../../assets/img/team-4.jpg";
import img16 from "../../assets/img/team-1.jpg";
import img17 from "../../assets/img/small-logos/logo-jira.svg";
import img18 from "../../assets/img/team-4.jpg";
import img19 from "../../assets/img/small-logos/logo-invision.svg";
import img20 from "../../assets/img/team-1.jpg";
import img21 from "../../assets/img/team-4.jpg";
import axios from 'axios';

export default {
  name: "projects-card",
  data() {
    return {
      tasks : [],
      successful_week_tasks : 0,
      img1,
      img2,
      img3,
      img4,
      img5,
      img6,
      img7,
      img8,
      img9,
      img10,
      img11,
      img12,
      img13,
      img14,
      img15,
      img16,
      img17,
      img18,
      img19,
      img20,
      img21,
    };
  },
  methods: {
    task_url(task){
        return "flows/" + task.uuid;
    },
    compute_percentage(task){
        if(task.state == "SUCCESS"){
            return 100;
        }
        if(task.state == "PROGRESS"){
            return 0;
        }
        return 0;
    },
    getTasks() {
      const path = 'http://localhost:5000/api/tasks';
      axios.get(path)
        .then((res) => {
          this.tasks = res.data.slice(0, 3);
        })
        .catch((error) => {
          console.error(error);
        });
    },
    getSuccessfulWeekTasks() {
      const path = 'http://localhost:5000/api/week-successful-tasks-count';
      axios.get(path)
        .then((res) => {
          this.successful_week_tasks = res.data;
        })
        .catch((error) => {
          console.error(error);
        });
    },
  },
  created() {
    this.getTasks();
    this.getSuccessfulWeekTasks();
  },
  components: {
    VsudProgress,
  },
  mounted() {
    setTooltip();

  },

};
</script>
