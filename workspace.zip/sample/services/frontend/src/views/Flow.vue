


<template>
    <div class="py-4 container-fluid">
        <div class="row">
            <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
                <mini-statistics-card
                        title="Today's Flows"
                        value="10 flows"
                        :percentage="{
            value: '+505%',
            color: 'text-success',
          }"
                        :icon="{
            component: 'ni ni-money-coins',
            background: iconBackground,
          }"
                        direction-reverse
                />
            </div>
            <div class="col-xl-3 col-sm-6 mb-xl-0 mb-4">
                <mini-statistics-card
                        title="Anomalies Detected"
                        value="+3,462"
                        :percentage="{
            value: '-2%',
            color: 'text-danger',
          }"
                        :icon="{
            component: 'ni ni-paper-diploma',
            background: iconBackground,
          }"
                        direction-reverse
                />
            </div>
        </div>
        <div class="row">
            <div class="col-lg-3 col-md-6">
                <timeline-list
                        class="h-100"
                        :title=uuid
                        :description=description()
                >
                    <timeline-item v-for="step in task.task_result.steps" :key="step.id"
                                   color="success"
                                   icon="bell-55"
                                   :title=step.label
                                   :date-time=step.time>
                    </timeline-item>
                </timeline-list>
            </div>
            <div class="col-lg-9 col-md-6">

                <div class="card h-100">
                    <div class="p-3 pb-0 card-header">
                        <h6 class="mb-0">Platform Settings</h6>
                    </div>
                    <div class="p-3 card-body">
                        <h6 class="text-xs text-uppercase text-body font-weight-bolder">
                            Global Settings
                        </h6>
                        <ul class="list-group">
                            <li class="px-0 border-0 list-group-item">
                                <vsud-switch
                                        id="flexSwitchCheckDefault"
                                        name="email"
                                        class="ps-0 ms-auto"
                                        label-class="mb-0 text-body ms-3 text-truncate w-80"
                                        checked
                                >Enable Tracking
                                </vsud-switch
                                >
                            </li>
                        </ul>
                        <h6 class="text-xs text-uppercase text-body font-weight-bolder">
                            KYC Data
                        </h6>
                        <ul class="list-group">
                            <li class="px-0 border-0 list-group-item">
                                <label>GCARS Report</label>
                                <vue3-simple-typeahead
                                        style="width:100%"
                                        id="gcars_input"
                                        placeholder="Start writing..."
                                        :items="['GCARS Report 2020','GCARS Report 2021','GCARS Report 2022']"
                                        :minInputLength="1"
                                        :itemProjection="itemProjectionFunction"
                                        @selectItem="selectItemEventHandler"
                                        @onInput="onInputEventHandler"
                                        @onFocus="onFocusEventHandler"
                                        @onBlur="onBlurEventHandler"
                                />
                            </li>
                            <li class="px-0 border-0 list-group-item">
                                <label>Sensitivity Report</label>
                                <vue3-simple-typeahead
                                        id="sensitivity_input"
                                        placeholder="Start writing..."
                                        :items="['Sensitivity Report 2020','Sensitivity Report 2021','Sensitivity Report 2022']"
                                        :minInputLength="1"
                                        :itemProjection="itemProjectionFunction"
                                        @selectItem="selectItemEventHandler"
                                        @onInput="onInputEventHandler"
                                        @onFocus="onFocusEventHandler"
                                        @onBlur="onBlurEventHandler"
                                />
                            </li>
                            <li class="px-0 border-0 list-group-item">
                                <label>KYC Reliance Worldwide Report</label>
                                <vue3-simple-typeahead
                                        id="kyc_reliance_input"
                                        placeholder="Start writing..."
                                        :items="['KYC Reliance Worldwide Report 2020','KYC Reliance Worldwide Report 2021','KYC Reliance Worldwide Report 2022']"
                                        :minInputLength="1"
                                        :itemProjection="itemProjectionFunction"
                                        @selectItem="selectItemEventHandler"
                                        @onInput="onInputEventHandler"
                                        @onFocus="onFocusEventHandler"
                                        @onBlur="onBlurEventHandler"
                                />
                            </li>
                            <li class="px-0 border-0 list-group-item">
                                <label>Country Risk Report</label>
                                <vue3-simple-typeahead
                                        id="country_risk_input"
                                        placeholder="Start writing..."
                                        :items="['Country Risk Report 2020','Country Risk Report 2021','Country Risk Report 2022']"
                                        :minInputLength="1"
                                        :itemProjection="itemProjectionFunction"
                                        @selectItem="selectItemEventHandler"
                                        @onInput="onInputEventHandler"
                                        @onFocus="onFocusEventHandler"
                                        @onBlur="onBlurEventHandler"
                                />
                            </li>
                        </ul>
                        <h6
                                class="mt-4 text-xs text-uppercase text-body font-weight-bolder"
                        >
                            AML Model
                        </h6>
                        <ul class="list-group">
                            <li class="px-0 border-0 list-group-item">
                                <label>GMM Threshold</label>
                                <vsud-input
                                        id="email"
                                        placeholder="0.0"
                                />
                            </li>
                        </ul>
                    </div>
                </div>

            </div>

        </div>
        <div class="row my-4">
            <div>
                <projects-card/>
            </div>
        </div>
    </div>
</template>
<script>
import axios from 'axios';
import TimelineList from "./components/TimelineList.vue";
import TimelineItem from "./components/TimelineItem.vue";
export default {
  name: "tables",
  data() {
    return {
      uuid : this.$route.params.uuid,
      task: {}
    };
  },
  methods: {
    description(){
        if(this.task.state == "SUCCESS"){
            return "<i class='fa fa-arrow-up text-success' aria-hidden='true'></i><span class='font-weight-bold'> " + this.task.state + "</span>";
        }else{
            return "<span class='font-weight-bold'> " + this.task.state + "</span>";
        }
    },
    compute_percentage(task){
        if(task.task_status == "SUCCESS"){
            return 100;
        }
        if(task.task_status == "PROGRESS"){
            return task.task_result.percentage;
        }
        return 0;
    },
    getTask() {
      const path = 'http://localhost:5000/api/task/raw/' + this.uuid;
      axios.get(path)
        .then((res) => {
          this.task = res.data;
        })
        .catch((error) => {
          console.error(error);
        });
    },
  },
  created() {
    this.getTask();
  },
  components: {
    TimelineList,TimelineItem
  },
};
</script>
