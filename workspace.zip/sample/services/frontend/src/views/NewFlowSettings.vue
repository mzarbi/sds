<style>
#gcars_input,#bu_input,#sensitivity_input,#kyc_reliance_input,#country_risk_input{
    display: block;
    width: 100%;
    padding: 0.5rem 0.75rem;
    font-size: 0.875rem;
    font-weight: 400;
    line-height: 1.4rem;
    color: #495057;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid #d2d6da;
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    border-radius: 0.5rem;
    transition: box-shadow 0.15s ease, border-color 0.15s ease;
}
</style>

<template>
  <div class="container-fluid">
    <div
      class="mt-4 page-header min-height-100 border-radius-xl"
      :style="{
        backgroundImage:
          'url(' + require('@/assets/img/curved-images/curved14.jpg') + ')',
        backgroundPositionY: '50%',
      }"
    >
      <span class="mask bg-gradient-success opacity-6"></span>
    </div>

  </div>
  <div class="py-4 container-fluid">
    <div class="mt-3 row">
      <div>
        <div class="card h-100">
          <div class="p-3 pb-0 card-header">
            <h6 class="mb-0">Create New Flow</h6>
          </div>
          <div class="p-3 card-body">
            <ul class="list-group">
              <li class="px-0 border-0 list-group-item">
                <label>Business Unit</label>
                <vue3-simple-typeahead
                    style="width:100%"
                    id="bu_input"
                    placeholder=""
                    :items="['GREAT BRITAIN','CZECH REPUBLIC','AUSTRALIA','KOREA']"
                    :minInputLength="1"
                    :itemProjection="itemProjectionFunction"
                    @selectItem="selectItemEventHandler"
                    @onInput="onInputEventHandler"
                    @onFocus="onFocusEventHandler"
                    @onBlur="onBlurEventHandler"
                />
              </li>
            </ul>
            <h6 class="text-xs text-uppercase text-body font-weight-bolder">
              Global Settings
            </h6>
            <ul class="list-group">
              <li class="px-0 border-0 list-group-item">
                <vsud-switch
                  id="flexSwitchCheckDefault"
                  name="email"
                  class="ps-0 ms-auto"
                  label-class="mb-0 text-body ms-3 text-truncate w-80"
                  checked
                  >Enable Tracking</vsud-switch
                >
              </li>
            </ul>
            <h6 class="text-xs text-uppercase text-body font-weight-bolder">
              KYC Data
            </h6>
            <ul class="list-group">
              <li class="px-0 border-0 list-group-item">
                <label>GCARS Report</label>
                <vue3-simple-typeahead
                    style="width:100%"
                    id="gcars_input"
                    placeholder="Start writing..."
                    :items="['GCARS Report 2020','GCARS Report 2021','GCARS Report 2022']"
                    :minInputLength="1"
                    :itemProjection="itemProjectionFunction"
                    @selectItem="selectItemEventHandler"
                    @onInput="onInputEventHandler"
                    @onFocus="onFocusEventHandler"
                    @onBlur="onBlurEventHandler"
                />
              </li>
              <li class="px-0 border-0 list-group-item">
                <label>Sensitivity Report</label>
                <vue3-simple-typeahead
                    id="sensitivity_input"
                    placeholder="Start writing..."
                    :items="['Sensitivity Report 2020','Sensitivity Report 2021','Sensitivity Report 2022']"
                    :minInputLength="1"
                    :itemProjection="itemProjectionFunction"
                    @selectItem="selectItemEventHandler"
                    @onInput="onInputEventHandler"
                    @onFocus="onFocusEventHandler"
                    @onBlur="onBlurEventHandler"
                />
              </li>
              <li class="px-0 border-0 list-group-item">
                <label>KYC Reliance Worldwide Report</label>
                <vue3-simple-typeahead
                    id="kyc_reliance_input"
                    placeholder="Start writing..."
                    :items="['KYC Reliance Worldwide Report 2020','KYC Reliance Worldwide Report 2021','KYC Reliance Worldwide Report 2022']"
                    :minInputLength="1"
                    :itemProjection="itemProjectionFunction"
                    @selectItem="selectItemEventHandler"
                    @onInput="onInputEventHandler"
                    @onFocus="onFocusEventHandler"
                    @onBlur="onBlurEventHandler"
                />
              </li>
              <li class="px-0 border-0 list-group-item">
                <label>Country Risk Report</label>
                <vue3-simple-typeahead
                    id="country_risk_input"
                    placeholder="Start writing..."
                    :items="['Country Risk Report 2020','Country Risk Report 2021','Country Risk Report 2022']"
                    :minInputLength="1"
                    :itemProjection="itemProjectionFunction"
                    @selectItem="selectItemEventHandler"
                    @onInput="onInputEventHandler"
                    @onFocus="onFocusEventHandler"
                    @onBlur="onBlurEventHandler"
                />
              </li>
            </ul>
            <h6
              class="mt-4 text-xs text-uppercase text-body font-weight-bolder"
            >
              AML Model
            </h6>
            <ul class="list-group">
              <li class="px-0 border-0 list-group-item">
                <label>GMM Threshold</label>
                <vsud-input
                  id="email"
                  placeholder="0.0"
                />
              </li>
            </ul>
            <button
                type="button"
                class="mb-0 btn btn-sm"
                v-on:click="startFlow"
              >
              Start Flow
              </button>
          </div>
        </div>
      </div>

    </div>

  </div>
</template>

<script>
import VsudSwitch from "@/components/VsudSwitch.vue";
import VsudInput from "@/components/VsudInput.vue";
import sophie from "@/assets/img/kal-visuals-square.jpg";
import marie from "@/assets/img/marie.jpg";
import ivana from "@/assets/img/ivana-square.jpg";
import peterson from "@/assets/img/team-4.jpg";
import nick from "@/assets/img/team-3.jpg";
import img1 from "@/assets/img/home-decor-1.jpg";
import img2 from "@/assets/img/home-decor-2.jpg";
import img3 from "@/assets/img/home-decor-3.jpg";
import team1 from "@/assets/img/team-1.jpg";
import team2 from "@/assets/img/team-2.jpg";
import team3 from "@/assets/img/team-3.jpg";
import team4 from "@/assets/img/team-4.jpg";
import {
  faFacebook,
  faTwitter,
  faInstagram,
} from "@fortawesome/free-brands-svg-icons";
import setNavPills from "@/assets/js/nav-pills.js";
import setTooltip from "@/assets/js/tooltip.js";
import axios from 'axios';
export default {
  name: "ProfileOverview",
  components: {
    VsudSwitch,
    VsudInput,
  },
  data() {
    return {
      showMenu: false,
      sophie,
      marie,
      ivana,
      peterson,
      nick,
      img1,
      team1,
      team2,
      team3,
      team4,
      img2,
      img3,
      faFacebook,
      faTwitter,
      faInstagram,
    };
  },
  methods: {
    startFlow() {
      const path = 'http://localhost:5000/api/tasks';
      axios.post(path,{type: 3})
        .then((res) => {
          this.$router.push({path: '/flows/' + res.data.task_id});

        })
        .catch((error) => {
          console.error(error);
        });
    },
    getClasses: (size, success, error) => {
      let sizeValue, isValidValue;

      sizeValue = size ? `form-control-${size}` : null;

      if (error) {
        isValidValue = "is-invalid";
      } else if (success) {
        isValidValue = "is-valid";
      } else {
        isValidValue = "";
      }

      return `${sizeValue} ${isValidValue}`;
    },
    getIcon: (icon) => (icon ? icon : null),
    hasIcon: (icon) => (icon ? "input-group" : null),
  },
  mounted() {
    this.$store.state.isAbsolute = true;
    setNavPills();
    setTooltip(this.$store.state.bootstrap);
  },
  beforeUnmount() {
    this.$store.state.isAbsolute = false;
  },
};
</script>
