import requests
from flow.models.flow_model import flow_model_from_dict
from flow.resources.loaders import load_json

flow_specs = load_json(r"C:\Users\medzi\Desktop\workspace\sample\flow.json")
PARAMS = {'flow_specs':flow_specs}
#r = requests.post('http://localhost:5000/api/tasks',json=PARAMS, verify=False).json()
#print(r)


r = requests.get('http://localhost:5000/api/task/sig/458004bb-6e6c-4f7f-bfa2-ef4da0d33b79', verify=False).json()
print(r)

