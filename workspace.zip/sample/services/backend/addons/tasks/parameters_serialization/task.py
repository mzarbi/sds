from flow.struct.abstract_task import AbstractTask
from flow.utils.decorators import skippable


class ParametersSerialization(AbstractTask):
    """This task will allow the user to perform xxxx"""

    def __init__(self,task_cfg, flow,lock):
        """
        Parameters Serialization Task constructor
        :param task_cfg: Task object (flow.models.flow_model.Task)
        :param flow: AbstractFlow object (flow.struct.abstract_flow.AbstractFlow)
        """
        super().__init__(task_cfg,flow,lock)
    
    def name(self):
        return 'Parameters Serialization'

    @skippable()
    def run(self):
        super().run()

    def update_task_state(self, value):
        self.flow.data[f'{self.task_cfg.marker}_on_success'] = value
