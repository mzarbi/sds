from flow.struct.abstract_task import AbstractNestedTask
from flow.utils.decorators import skippable


class LoadingKycData(AbstractNestedTask):
    """This task will allow the user to perform xxxx"""

    def __init__(self,task_cfg, flow,parent_task,lock):
        super().__init__(task_cfg, flow,parent_task,lock)
    
    def name(self):
        return 'Loading Kyc Data'
        
    @skippable()
    def run(self):
        super().run()

    def update_task_state(self, value):
        self.flow.data[f'{self.task_cfg.marker}_on_success'] = value



class LoadingCrds(AbstractNestedTask):
    """This task will allow the user to perform xxxx"""

    def __init__(self,task_cfg, flow,parent_task,lock):
        super().__init__(task_cfg, flow,parent_task,lock)
    
    def name(self):
        return 'Loading Crds'
        
    @skippable()
    def run(self):
        super().run()

    def update_task_state(self, value):
        self.flow.data[f'{self.task_cfg.marker}_on_success'] = value



class InjectingKyc(AbstractNestedTask):
    """This task will allow the user to perform xxxx"""

    def __init__(self,task_cfg, flow,parent_task,lock):
        super().__init__(task_cfg, flow,parent_task,lock)
    
    def name(self):
        return 'Injecting Kyc'
        
    @skippable()
    def run(self):
        super().run()

    def update_task_state(self, value):
        self.flow.data[f'{self.task_cfg.marker}_on_success'] = value



class ComputingFeatures(AbstractNestedTask):
    """This task will allow the user to perform xxxx"""

    def __init__(self,task_cfg, flow,parent_task,lock):
        super().__init__(task_cfg, flow,parent_task,lock)
    
    def name(self):
        return 'Computing Features'
        
    @skippable()
    def run(self):
        super().run()

    def update_task_state(self, value):
        self.flow.data[f'{self.task_cfg.marker}_on_success'] = value
