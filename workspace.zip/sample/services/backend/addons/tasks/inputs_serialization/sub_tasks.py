from flow.struct.abstract_task import AbstractNestedTask
from flow.utils.decorators import skippable


class LoadingThresholds(AbstractNestedTask):
    """This task will allow the user to perform xxxx"""

    def __init__(self,task_cfg, flow,parent_task,lock):
        super().__init__(task_cfg, flow,parent_task,lock)
    
    def name(self):
        return 'Loading Thresholds'
        
    @skippable()
    def run(self):
        super().run()

    def update_task_state(self, value):
        self.flow.data[f'{self.task_cfg.marker}_on_success'] = value



class SerializingTransactions(AbstractNestedTask):
    """This task will allow the user to perform xxxx"""

    def __init__(self,task_cfg, flow,parent_task,lock):
        super().__init__(task_cfg, flow,parent_task,lock)
    
    def name(self):
        return 'Serializing Transactions'
        
    @skippable()
    def run(self):
        super().run()

    def update_task_state(self, value):
        self.flow.data[f'{self.task_cfg.marker}_on_success'] = value



class SerializingAlerts(AbstractNestedTask):
    """This task will allow the user to perform xxxx"""

    def __init__(self,task_cfg, flow,parent_task,lock):
        super().__init__(task_cfg, flow,parent_task,lock)
    
    def name(self):
        return 'Serializing Alerts'
        
    @skippable()
    def run(self):
        super().run()

    def update_task_state(self, value):
        self.flow.data[f'{self.task_cfg.marker}_on_success'] = value



class SerializingItAlerts(AbstractNestedTask):
    """This task will allow the user to perform xxxx"""

    def __init__(self,task_cfg, flow,parent_task,lock):
        super().__init__(task_cfg, flow,parent_task,lock)
    
    def name(self):
        return 'Serializing It Alerts'
        
    @skippable()
    def run(self):
        super().run()

    def update_task_state(self, value):
        self.flow.data[f'{self.task_cfg.marker}_on_success'] = value
