from flow.struct.abstract_task import AbstractNestedTask
from flow.utils.decorators import skippable


class ComputeOrInjectClusters(AbstractNestedTask):
    """This task will allow the user to perform xxxx"""

    def __init__(self,task_cfg, flow,parent_task,lock):
        super().__init__(task_cfg, flow,parent_task,lock)
    
    def name(self):
        return 'Compute Or Inject Clusters'
        
    @skippable()
    def run(self):
        super().run()

    def update_task_state(self, value):
        self.flow.data[f'{self.task_cfg.marker}_on_success'] = value

    def update_compute_clusters_slot(self,value):
        self.flow.data[f'{self.task_cfg.marker}_compute_clusters'] = value



class ComputeClusters(AbstractNestedTask):
    """This task will allow the user to perform xxxx"""

    def __init__(self,task_cfg, flow,parent_task,lock):
        super().__init__(task_cfg, flow,parent_task,lock)
    
    def name(self):
        return 'Compute Clusters'
        
    @skippable()
    def run(self):
        super().run()

    def update_task_state(self, value):
        self.flow.data[f'{self.task_cfg.marker}_on_success'] = value



class InjectClusters(AbstractNestedTask):
    """This task will allow the user to perform xxxx"""

    def __init__(self,task_cfg, flow,parent_task,lock):
        super().__init__(task_cfg, flow,parent_task,lock)
    
    def name(self):
        return 'Inject Clusters'
        
    @skippable()
    def run(self):
        super().run()

    def update_task_state(self, value):
        self.flow.data[f'{self.task_cfg.marker}_on_success'] = value
