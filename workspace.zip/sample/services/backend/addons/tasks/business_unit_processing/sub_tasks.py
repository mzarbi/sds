from flow.struct.abstract_task import AbstractNestedTask
from flow.utils.decorators import skippable


class RemovingDomesticDebitFromPayments(AbstractNestedTask):
    """This task will allow the user to perform xxxx"""

    def __init__(self,task_cfg, flow,parent_task,lock):
        super().__init__(task_cfg, flow,parent_task,lock)
    
    def name(self):
        return 'Removing Domestic Debit From Payments'
        
    @skippable()
    def run(self):
        super().run()

    def update_task_state(self, value):
        self.flow.data[f'{self.task_cfg.marker}_on_success'] = value



class RemovingDomesticDebitFromPostings(AbstractNestedTask):
    """This task will allow the user to perform xxxx"""

    def __init__(self,task_cfg, flow,parent_task,lock):
        super().__init__(task_cfg, flow,parent_task,lock)
    
    def name(self):
        return 'Removing Domestic Debit From Postings'
        
    @skippable()
    def run(self):
        super().run()

    def update_task_state(self, value):
        self.flow.data[f'{self.task_cfg.marker}_on_success'] = value
