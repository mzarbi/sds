from threading import Lock
import os
from flask import Blueprint, request, jsonify
from flow.manifest import ManifestDB, Query
from flow.models.flow_model import flow_model_from_dict
from flow.resources.loaders import load_json
from flow.struct.abstract_executor import CustomThreadPoolExecutor

api_blueprint = Blueprint("api", __name__, url_prefix='/api')
executor = CustomThreadPoolExecutor(max_workers=3, lock=Lock())


def load_manifest():
    manifest_path = os.environ["CACHE_PATH"] + "/" + "manifest.json"
    return ManifestDB(manifest_path)


@api_blueprint.route("/tasks", methods=["POST"])
def run_flow():
    content = request.json
    # flow_specs = flow_model_from_dict(content["flow_specs"])
    flow_specs = flow_model_from_dict(load_json(r"C:\Users\medzi\Desktop\workspace\sample\flow.json"))
    uuid = executor.register_flow(flow_specs)
    return jsonify({"task_id": uuid}), 202


@api_blueprint.route("/tasks", methods=["GET"])
def fetch_tasks():
    return jsonify([{
        "uuid": f["uuid"],
        "start": f.get("start", ""),
        "end": f.get("end", ""),
        "state": f.get("state", "")
    } for f in load_manifest().all()]), 202


@api_blueprint.route("/task/raw/<task_id>", methods=["GET"])
def task(task_id):
    ls = load_manifest().search(Query().uuid == task_id)
    return jsonify(ls[0] if len(ls) > 0 else {}), 200


@api_blueprint.route("/task/sig/<task_id>", methods=["GET"])
def task_signature(task_id):
    def compute_progress(task):
        if task.get("state", "") == "SUCCESS":
            return 100
        else:
            return 0

    ls = [{
        "uuid": f["uuid"],
        "start": f.get("start", ""),
        "end": f.get("end", ""),
        "state": f.get("state", ""),
        "progress": compute_progress(f)
    } for f in load_manifest().search(Query().uuid == task_id)]
    return jsonify(ls[0] if len(ls) > 0 else {}), 200


@api_blueprint.route("/task/breakpoints/<task_id>", methods=["GET"])
def task_breakpoints(task_id):
    ls = [[g for g in f.get("breakpoints", [])] for f in load_manifest().search(Query().uuid == task_id)]

    ls = ls[0] if len(ls) > 0 else []
    ls2 = [i for i in ls if i.get("parent", None) is None]
    for i in ls2:
        i.update({
            "sub-breakpoints": [j for j in ls if j.get("parent", None) == i["uuid"]]
        })
    return jsonify(ls2), 200
