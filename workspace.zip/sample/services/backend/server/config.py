class BaseConfig:
    TESTING = False


class DevelopmentConfig(BaseConfig):
    TESTING = False
    WTF_CSRF_ENABLED = False


class TestingConfig(BaseConfig):
    TESTING = True
    WTF_CSRF_ENABLED = False
    PRESERVE_CONTEXT_ON_EXCEPTION = False


class ProductionConfig(BaseConfig):
    TESTING = False
    WTF_CSRF_ENABLED = False