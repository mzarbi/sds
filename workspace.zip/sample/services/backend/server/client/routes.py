from flask import render_template, Blueprint

client_blueprint = Blueprint("main", __name__,)


@client_blueprint.route("/", methods=["GET"])
def home():
    return render_template("main/home.html")